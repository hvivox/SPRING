package com.algaworks.algaworks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgaworksApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlgaworksApplication.class, args);
	}

}
