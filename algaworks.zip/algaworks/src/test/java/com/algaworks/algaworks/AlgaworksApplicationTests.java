package com.algaworks.algaworks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlgaworksApplicationTests {

	@Test
	void contextLoads() {
	}

}
